#ifndef CALLC_H
#define CALLC_H

void cHello();
void printMessage(char* message);

#endif