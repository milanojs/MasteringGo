package main

import (
	"fmt"
)

func main()
{
	fmt.Println("Go has strict rules for curly braces!")
}

