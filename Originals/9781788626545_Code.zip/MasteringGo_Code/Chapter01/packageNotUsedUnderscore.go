package main

import (
	"fmt"
	_ "os"
)

func main() {
	fmt.Println("Hello there!")
}
